document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('#calculator-form');
    const resultsDiv = document.querySelector('#results');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const num1 = parseInt(document.querySelector('#num1').value);
        const num2 = parseInt(document.querySelector('#num2').value);

        if (isNaN(num1) || isNaN(num2)) {
            resultsDiv.textContent = 'Por favor, insira numeros validos.';
            return;
        }

        const sum = num1 + num2;
        const subtract = num1 - num2;
        const multiply = num1 * num2;
        const divide = num2 !== 0 ? num1 / num2 : 'Nao e posivel dividir por zero';

        resultsDiv.innerHTML = `
            <p>Soma: ${sum}</p>
            <p>Subtracao: ${subtract}</p>
            <p>Multiplicacao: ${multiply}</p>
            <p>Divisao: ${divide}</p>
        `;
    });
});