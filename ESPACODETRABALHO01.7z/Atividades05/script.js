function ordenarPessoas() {

    const nome1 = document.querySelector('#nome1').value;
    const ano1 = parseInt(document.querySelector('#ano1').value);
    const nome2 = document.querySelector('#nome2').value;
    const ano2 = parseInt(document.querySelector('#ano2').value);
    const nome3 = document.querySelector('#nome3').value;
    const ano3 = parseInt(document.querySelector('#ano3').value);


    const anoAtual = new Date().getFullYear();


    const idade1 = anoAtual - ano1;
    const idade2 = anoAtual - ano2;
    const idade3 = anoAtual - ano3;


    const pessoas = [
        { nome: nome1, idade: idade1 },
        { nome: nome2, idade: idade2 },
        { nome: nome3, idade: idade3 }
    ];


    pessoas.sort((a, b) => b.idade - a.idade);


    const resultado = document.querySelector('#resultado');
    resultado.innerHTML = `
        <p>Pessoa mais velha: ${pessoas[0].nome} - ${pessoas[0].idade} anos</p>
        <p>Segunda pessoa mais velha: ${pessoas[1].nome} - ${pessoas[1].idade} anos</p>
        <p>Terceira pessoa mais velha: ${pessoas[2].nome} - ${pessoas[2].idade} anos</p>
    `;
}
