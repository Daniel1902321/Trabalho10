function dividirAlunos() {

    const numAlunos = parseInt(document.querySelector('#numAlunos').value);
    const numTurmas = parseInt(document.querySelector('#numTurmas').value);
    

    const alunosPorTurma = Math.floor(numAlunos / numTurmas);
    const alunosSemTurma = numAlunos % numTurmas;
    

    const resultado = document.querySelector('#resultado');
    resultado.innerHTML = `
        <p>Quantidade de Alunos por Turma: ${alunosPorTurma}</p>
        <p>Quantidade de Alunos Sem Turma: ${alunosSemTurma}</p>
    `;
}
