function calcular() {
    var dolarAtual = parseFloat(document.querySelector("#dolar").value);
    if (isNaN(dolarAtual)) {
        alert("Por favor, insira um valor válido para a cotação do dólar.");
        return;
    }

    var aumentos = [1, 2, 5, 10];
    var resultado= "<h3>Resultados:</h3>";
    for (var i = 0; i < aumentos.length; i++) {
        var aumento = aumentos[i] / 100;
        var novoValor = dolarAtual + (dolarAtual * aumento);
        resultado += "<p>Se a cotação subir " + aumentos[i] + "%, o valor será: $" + novoValor.toFixed(2) + "</p>";
    }

    document.getElementById("resultado").innerHTML = resultado;
}
