function verificarMetas() {

    const valorVendido = parseFloat(document.querySelector('#valorVendido').value);
    const meta = parseFloat(document.querySelector('#meta').value);
    const metaMinima = parseFloat(document.querySelector('#metaMinima').value);
    

    const percentualMeta = (valorVendido / meta) * 100;
    const percentualMetaMinima = (valorVendido / metaMinima) * 100;

    let mensagem;
    if (valorVendido >= meta) {
        mensagem = "Atingiu a meta.";
    } else if (valorVendido >= metaMinima) {
        mensagem = "Atingiu a meta mínima.";
    } else {
        mensagem = "Não atingiu nenhuma das metas.";
    }


    const resultado = document.querySelector('#resultado');
    resultado.innerHTML = `
        <p>${mensagem}</p>
        <p>Percentual de Atingimento da Meta: ${percentualMeta.toFixed(2)}%</p>
        <p>Percentual de Atingimento da Meta Mínima: ${percentualMetaMinima.toFixed(2)}%</p>
    `;
}
