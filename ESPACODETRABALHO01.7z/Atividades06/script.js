function verificarNota() {

    const notaFinal = parseFloat(document.querySelector('#notaFinal').value);
    

    let mensagem;
    if (notaFinal >= 6) {
        mensagem = "Aprovado";
    } else if (notaFinal > 4) {
        mensagem = "Precisa fazer prova substitutiva";
    } else {
        mensagem = "Reprovado";
    }


    const resultado = document.querySelector('#resultado');
    resultado.innerHTML = `<p>${mensagem}</p>`;
}
