function calcular() {
    var pessoas = parseInt(document.querySelector("#pessoas").value);
    if (isNaN(pessoas) || pessoas <= 0) {
        alert("Por favor, insira um número válido de pessoas.");
        return;
    }

    var ovosPorPessoa = 2;
    var queijoPorPessoa = 50;

    var totalOvos = pessoas * ovosPorPessoa;
    var totalQueijo = pessoas * queijoPorPessoa;

    var 
    resultadoHTML = "<h3>Ingredientes necessarios:</h3>";
    resultadoHTML += "<p>Omeletes para " + pessoas + " pessoas:</p>";
    resultadoHTML += "<li>" + totalOvos + " ovos</li>";
    resultadoHTML += "<li>" + totalQueijo + " gramas de queijo</li>";

    document.getElementById("resultado").innerHTML = resultadoHTML;
}