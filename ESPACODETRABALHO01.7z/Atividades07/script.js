function compararNumeros() {

    const numero1 = parseInt(document.querySelector('#numero1').value);
    const numero2 = parseInt(document.querySelector('#numero2').value);
    

    let mensagem;
    if (numero1 > numero2) {
        mensagem = "O primeiro número é maior que o segundo.";
    } else if (numero1 < numero2) {
        mensagem = "O primeiro número é menor que o segundo.";
    } else {
        mensagem = "Os dois números são iguais.";
    }

    const resultado = document.querySelector('#resultado');
    resultado.innerHTML = `<p>${mensagem}</p>`;
}
