function calcularTotal() {

    const sabor1 = document.querySelector('#sabor1').value;
    const sabor2 = document.querySelector('#sabor2').value;
    const sabor3 = document.querySelector('#sabor3').value;
    const sabor4 = document.querySelector('#sabor4').value;
    const refrigerantes = parseInt(document.querySelector('#refrigerantes').value);


    const precoPizza = 12.00;
    const precoRefrigerante = 7.00;


    const totalPizzas = 4 * precoPizza;
    const totalRefrigerantes = refrigerantes * precoRefrigerante;
    const valorTotal = totalPizzas + totalRefrigerantes;


    const resumoPedido = document.querySelector('#resumoPedido');
    resumoPedido.innerHTML = `
        <p>Sabor 1: ${sabor1}</p>
        <p>Sabor 2: ${sabor2}</p>
        <p>Sabor 3: ${sabor3}</p>
        <p>Sabor 4: ${sabor4}</p>
        <p>Refrigerantes: ${refrigerantes}</p>
        <p><strong>Valor Total a Pagar: R$ ${valorTotal.toFixed(2)}</strong></p>
    `;
}
