function verificarParOuImpar() {

    const numero = parseInt(document.querySelector('#numero').value);
    

    let mensagem;
    if (numero % 2 === 0) {
        mensagem = "O número é Par.";
    } else {
        mensagem = "O número é Ímpar.";
    }


    const resultado = document.querySelector('#resultado');
    resultado.innerHTML = `<p>${mensagem}</p>`;
}
